<template>
  <div class="app">
    <RouterView @login-success="loginSuccess" @logout="handelLogout"></RouterView>
  </div>
</template>

<script setup>
import { ref, watchEffect, onMounted, computed } from 'vue';

const router = useRouter();
const isLoggedIn = ref(false);

const loginSuccess = (token) => {
  // 處理登錄成功的邏輯，例如存儲 token
  isLoggedIn.value = true
  console.log(token, isLoggedIn.value);
  // 其他邏輯...
  router.push({ name: 'Home' });
}
const handelLogout = (logstatus)=>{
  isLoggedIn.value = logstatus
  console.log(isLoggedIn.value, logstatus)
}
onMounted(() => {
  // const token = localStorage.getItem('userToken');
  // if (token) {
  //   isLoggedIn.value = true;
  // }
  isLoggedIn.value = false
});

</script>