<template>
    <div class="Main">
        <h1>設定</h1>
    </div>  
</template>

<script setup>
</script>

<style scoped>

.Main {
    display: flex;
    min-height: 90dvh;
 
    color: white;
  }
</style>
