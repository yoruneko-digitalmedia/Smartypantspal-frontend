<template>
    <n-config-provider :theme="theme" :theme-overrides="themeOverrides">
    <!-- <n-config-provider :theme="theme">  -->
        <n-layout>
            <n-layout-header bordered>
                <n-flex class="nav_bar" justify="space-around" size="large" >
                    <div class="title">ITS</div>
                    <navigationbar :std_number=std_number  @logout="handelLogout"/>
                    <div>
                    <!-- <n-switch :round="false" v-model:value="active" @update:value="handleChange" size="large">
                        <template #checked>
                        light&nbsp;off
                        後悔了吧哈哈
                        </template>
                        <template #unchecked>
                        light&nbsp;on
                        &nbsp;&nbsp;點了會瞎掉
                        </template>
                    </n-switch> -->
                    <ThemeSwitch @theme-change="handleChange" />
                    </div>
                </n-flex>
            </n-layout-header>
        <n-layout>
          <n-message-provider>
            <n-dialog-provider>
              <div class="router">
                <n-scrollbar style="max-height: 93vh;">
                  <router-view />
                </n-scrollbar>
              </div>
            </n-dialog-provider>
          </n-message-provider>
        </n-layout>
      </n-layout>
    </n-config-provider>
</template>
<script setup>
import { ref, watchEffect, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';
import navigationbar from '../components/navigationbar.vue';
 
import ThemeSwitch from '../components/ThemeSwitch.vue';
 
import { 
  NConfigProvider, 
  NMessageProvider,
  NDialogProvider,
  NScrollbar, 
  NSpace, 
  NLayout, 
  NLayoutHeader,
  NSwitch,
  darkTheme } from 'naive-ui';
import darkthemeOverrides from '../assets/naive-ui-dark-theme-overrides.json';
import lightthemeOverrides from '../assets/naive-ui-light-theme-overrides.json';
const theme = ref(darkTheme); // Set initial theme
const active = ref(false);
const std_number =ref("7112056461");
const router = useRouter();
const isLoggedIn = ref(false);
// const token = ref(null);
// const logstatus = ref(false);
const emit = defineEmits(['logout']);
let themeOverrides = darkthemeOverrides
const switchTheme = (value) => {
  if (value) {
    theme.value = null;
    themeOverrides = null
    document.body.classList.remove('dark-theme');
    document.body.classList.add('light-theme');
  } else {
    theme.value = darkTheme;
    document.body.classList.remove('light-theme');
    themeOverrides = darkthemeOverrides
    document.body.classList.add('dark-theme');
  }
};

// Handle theme change when the switch value is updated
const handleChange = (value) => {
  console.log(value)
  switchTheme(value);
};
const loginSuccess = (token) => {
  // 處理登錄成功的邏輯，例如存儲 token
  isLoggedIn.value = true
  console.log(token, isLoggedIn.value);
  // 其他邏輯...
  router.push({ name: 'Home' });
}
const handelLogout = (logstatus)=>{
  isLoggedIn.value = logstatus
  const token = isLoggedIn;  
  emit('logout', token.value);
  console.log(isLoggedIn.value, logstatus, token.value)
}
onMounted(() => {

  isLoggedIn.value = false
  // const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
  // console.log(prefersDarkScheme)
  // switchTheme(prefersDarkScheme.matches ? false : true);
  switchTheme(false);
});
 
</script>
<style scoped>
.router {
  position: relative;
  height: 95vh;
}
 
.nav_bar {
  padding: 2.5vh 0 2.5vh 0;
  display: flex;
  justify-content: center;
  justify-items: center;
  align-items: center;
} 
.title{
  font-weight: bold;
  font-size: 25px;
}
 

</style>