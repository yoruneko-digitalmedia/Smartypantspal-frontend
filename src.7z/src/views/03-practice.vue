<template>
    <div class="Main">
        <h1>練習系統</h1>
    </div>  
</template>

<script setup>
</script>

<style scoped>
.Main {
  display: flex;
  min-height: 90dvh;

  color: white;
}
</style>
