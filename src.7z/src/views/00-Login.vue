<template>
  <div class="main">
    <n-config-provider :theme="theme" :theme-overrides="themeOverrides">
      <n-space vertical class="content">
        <n-card>
          
          <n-tabs
            class="card-tabs"
            default-value="signin"
            size="large"
            animated
            pane-wrapper-style="margin: 0 -4px"
            pane-style="padding-left: 4px; padding-right: 4px; box-sizing: border-box;"
          >
            <n-tab-pane name="signin" tab="Login">
              <n-form>
                <n-form-item-row label="User name">
                  <n-input v-model:value="username" type="text" placeholder="Username" />
                </n-form-item-row>
                <n-form-item-row label="Password">
                  <n-input v-model:value="password" type="password" placeholder="Password" />
                </n-form-item-row>
              </n-form>
              <!-- <div style="padding: 5px;"> 
                <ThemeSwitch @theme-change="handleChange" />
              </div> -->
              <n-button @click="handleLogin" type="primary" block secondary strong>
                Login
              </n-button>
            </n-tab-pane>
            <!-- <n-tab-pane name="signup" tab="Sign_up">
              <n-form>
                <n-form-item-row label="User name">
                  <n-input v-model="username" />
                </n-form-item-row>
                <n-form-item-row label="Password">
                  <n-input v-model="password" type="password" />
                </n-form-item-row>
                <n-form-item-row label="Repeat Password">
                  <n-input v-model="repeatPassword" type="password" />
                </n-form-item-row>
                <n-form-item-row label="E-mail">
                  <n-input v-model="email" />
                </n-form-item-row>
              </n-form>
              <n-button @click="handleSignUp" type="primary" block secondary strong>
                Sign up
              </n-button>
            </n-tab-pane> -->
          </n-tabs>
        </n-card>
      </n-space>
    </n-config-provider>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import axios from 'axios'
import { darkTheme } from 'naive-ui';
import darkthemeOverrides from '../assets/naive-ui-dark-theme-overrides.json';
import lightthemeOverrides from '../assets/naive-ui-light-theme-overrides.json';
import ThemeSwitch from '../components/ThemeSwitch.vue';
 
const theme = ref(darkTheme); // Set initial theme
const active = ref(false);
const emit = defineEmits(['login-success']);

const username = ref('');
const password = ref('');
const repeatPassword = ref('');
const email = ref('');
let themeOverrides = darkthemeOverrides
const switchTheme = (value) => {
  if (value) {
    theme.value = null;
    themeOverrides = null
    document.body.classList.remove('dark-theme');
    document.body.classList.add('light-theme');
  } else {
    theme.value = darkTheme;
    document.body.classList.remove('light-theme');
    themeOverrides = darkthemeOverrides
    document.body.classList.add('dark-theme');
  }
};

// Handle theme change when the switch value is updated
const handleChange = (value) => {
  console.log(value)
  switchTheme(value);
};
const handleLogin = () => {

  axios.post('http://127.0.0.1/loginn', {
    email: username.value, // ?���O�n?�e��?�u
    password: password.value
  }, {
    withCredentials: true, // ?�̫O�F���?�D??? cookies
    // ��L�t�m...
  })
    .then(response => {
      console.log("!!!!!!!!!!!");
      console.log("@@", response.data);
      emit('login-success', response.data);
    })
    .catch(error => {
      console.error(error);
      message.error('something went wrong');
    });
};

const handleSignUp = () => {
  // Perform sign-up logic, e.g., send request to backend with user details
  // If sign-up is successful, emit the 'login-success' event
  const token = 'your_token_from_backend'; // Replace this with the actual token from backend
  emit('login-success', token);
};
onMounted(() => {
  // Add watcher for prefers-color-scheme
  const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
  console.log(prefersDarkScheme)
  switchTheme(prefersDarkScheme.matches ? false : true);

  // Watch for changes in the prefers-color-scheme
  // watch(() => prefersDarkScheme.matches, (newVal) => {
  //   switchTheme(newVal);
  // });
});
</script>

<style scoped>
.main {
  height: 100vh;
  width: 100vw;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgb(39, 94, 107); /**/
}
 
.content {
  
  text-align: center;
  font-size: 32px;
}
 
</style>
