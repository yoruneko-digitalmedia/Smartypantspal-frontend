<template>
  <div class="Main">
    <h1>首頁</h1>
  </div>  
</template>

<script setup>
</script>

<style scoped>
.Main {
  display: flex;
  min-height: 90dvh;

}
</style>
