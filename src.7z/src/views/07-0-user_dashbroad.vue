<template>
    <div class="Main">
        <h1>使用者頁面</h1>
    </div>  
</template>

<script setup>
</script>

<style scoped>
.Main {
  display: flex;
  min-height: 90dvh;

  color: white;
}
</style>
