import { createRouter, createWebHistory } from 'vue-router'
import main from '../views/00-main.vue';
import Login from '../views/00-Login.vue';
import axios from 'axios'


const routes = [  {
    path: '/login',
    name: 'Login',
    component: Login,
    // meta: { requiresAuth: true },
    beforeEnter: async (to, from, next) => {
      // if (to.fullPath === '/') return;
      await check_function(to, from, next);
    }

  },
  {
    path: '/main',
    name: 'main',
    redirect: '/main/home',
    component: main,
    // meta: { requiresAuth: true },
    beforeEnter: async (to, from, next) => {
      // if (to.fullPath === '/') return;
      await check_function(to, from, next);
    },
    children: [
      {
        path: 'home',

        name: 'Home',
        component: () => import('../views/01-Home.vue')

      },
      {
        path: 'test',
        name: 'test',
        // meta: { requiresAuth: true },
        component: () => import('../views/02-test.vue')
      },
      {
        path: 'practice',
        name: 'practice',
        // meta: { requiresAuth: true },
        component: () => import('../views/03-practice.vue')
      },
      {
        path: 'analize',
        name: 'analize',
        // meta: { requiresAuth: true },
        component: () => import('../views/04-analize.vue')
      },
      {
        path: 'manage',
        name: 'manage',
        // meta: { requiresAuth: true },
        component: () => import('../views/05-manage.vue')
      },
      {
        path: 'class',
        name: 'class',
        // meta: { requiresAuth: true },
        component: () => import('../views/06-class.vue')
      },
      {
        path: 'user_dashbroad',
        name: 'user_dashbroad',
        // meta: { requiresAuth: true },
        component: () => import('../views/07-0-user_dashbroad.vue')
      },
      {
        path: 'setting',
        name: 'setting',
        // meta: { requiresAuth: true },
        component: () => import('../views/07-1-setting.vue')
      },

    ]
  },
  {
    path: '/',
    redirect: '/main/home' // 或任何你希望作为默认页面的路由
  },
  {
    path: '/:catchAll(.*)', // 使用自定義正則表達式
    redirect: '/login', // 將未定義的路徑導向首頁
  },
  // 將未定義的路徑導向首頁
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
})
const check_function = async (to, from, next) => {
  try {
    const response = await axios.get('http://127.0.0.1/login_check', { withCredentials: true });
    console.log(response)
    // 假设 response.data.isAuthenticated 表示用户认证状态
    if (response.data[4] == true) {
      // 如果用户已登录，并且尝试访问登录页，则重定向到主页或其他页面
      if (to.path === '/login') {
        console.log('11')
        next(from.path); // 或你的应用默认主页
      } else {
        console.log('22')
        next(); // 继续到目标路由
      }
    } else {
      // 如果用户未登录，则重定向到登录页
      console.log('33')
      if (to.path !== '/login') {
        console.log('44')
        next('/login');
      } else {
        console.log('55')
        next(); // 已经在登录页，无需重定向
      }
    }
  } catch (error) {
    // 请求出错，重定向到登录页面
    console.error(error);
    next('/login');
  }
};

// const check_function = async (to, from, next) => {// 定义自执行的异步函数

//   // if (true) {
//   console.log("!@!#@#$")
//   try {
//     const response = await axios.get('http://127.0.0.1/login_check', { withCredentials: true }); // withCredentials: true 使请求带上跨域cookies
//     console.log(response, "SDSD");
//     // 基于响应决定是否继续导航
//     if (response.data[4] == true) {
//       console.log(to, "Das", to.fullPath)
//       if (to.fullPath == '/login') {
//         console.log('ccc')
//         // router.push(from.fullPath)
//         // return
//         return { path: from.path}
//       }
//       next(); // 如果用户已登录，继续导航
//       console.log("@#$$");


//       return
//     } else {
//       console.log("@xczxc");
//       next({ name: 'Login' }); // 如果用户未登录，重定向到登录页面
//       return
//     }
//   } catch (error) {
//     console.error(error);
//     next({ name: 'Login' }); // 请求出错，也重定向到登录页面
//     return
//   }
//   // } else {
//   //   next(); // 对于不需要认证的路由，直接放行
//   //   return
//   // }
// };

// router.beforeEach(async (to, from, next) => {
//   if (to.fullPath === '/') return;
//   await check_function(to, from, next);
// });


export default router
