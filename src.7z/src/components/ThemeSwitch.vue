<template>
    <div>
        <n-switch :round="false" v-model:value="active" @update:value="handleChange" size="large">
        <template #checked>
            後悔了吧哈哈
        </template>
        <template #unchecked>
            &nbsp;&nbsp;點了會瞎掉
        </template>
        </n-switch>
    </div>
</template>

<script setup>
    import { ref } from 'vue';
    // const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    const active = ref(false);
    const emit = defineEmits(['theme-change']);
    const handleChange = (value) => {
    // Emit an event to notify the parent component (App.vue)
        emit('theme-change', value);
    };
</script>
  