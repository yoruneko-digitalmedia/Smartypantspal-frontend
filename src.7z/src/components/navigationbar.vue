<template>
  <div>
    <n-menu 
    v-model:value="activeKey" 
    mode="horizontal" 
    :options="menuOptions" 
    responsive 
    />
    
</div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import { RouterLink, useRouter } from 'vue-router';
import { NMenu, NIcon, NButton } from "naive-ui";
import {
  HomeOutline as HomeIcon,
  Build as BuildIcon,
  PersonCircleOutline as personIcon,
  LogOutOutline as LogOutIcon,
  PeopleOutline as PeopleIcon,
  PodiumOutline as Podium,
  TrendingUpSharp as TrendingUp,
  TerminalOutline as Terminal,
  LibraryOutline as Library,
  BookOutline as Book
} from "@vicons/ionicons5";
import axios from 'axios'
const { proxyRefs } = getCurrentInstance();
const route = useRouter();
const activeKey = ref('Home');
const props = defineProps(['std_number'])

const emit = defineEmits(['logout']);
// const instance = getCurrentInstance();
const renderIcon = (icon) => () => h(NIcon, null, { default: () => h(icon) });



// Perform login logic, e.g., send request to backend with username and password
// If login is successful, emit the 'login-success' event
// const token = 'your_token_from_backend'; // Replace this with the actual token from backend


const menuOptions = ref([
  {
    label: () => h(
      RouterLink,
      {to: {name: "Home"}},
      { default: () => '首頁' }
    ),
    key: 'Home',
    icon: renderIcon(HomeIcon)
  },
  {
    label: () => h(
      RouterLink,
      {to: {name: "test"}},
      { default: () => '測驗系統' }
    ),
    key: 'test',
    icon: renderIcon(Book)
  },
  {
    label: () => h(
      RouterLink,
      {to: {name: "practice"}},
      { default: () => '練習系統' }
    ),
    key: 'practice',
    icon: renderIcon(Library)
  },
  {
    label: () => h(
      RouterLink,
      {to: {name: "analize"}},
      { default: () => '數據分析' }
    ),
    key: 'analize',
    icon: renderIcon(TrendingUp)
  },
  {
    label: () => h(
      RouterLink,
      {to: {name: "manage"}},
      { default: () => '後台系統' }
    ),
    key: 'manage',
    icon: renderIcon(Terminal)
  },
  {
    label: () => h(
      RouterLink,
      {to: {name: "class"}},
      { default: () => '教師系統' }
    ),
    key: 'class',
    icon: renderIcon(Podium)
  },
  {
    label: props.std_number,
    key: '',
    icon: renderIcon(PeopleIcon),
    children: [
      {
        label: () => h(
          RouterLink,
          { to: { name: "user_dashbroad" } },
          { default: () => "使用者" }
        ),
        key: "user_dashbroad",
        icon: renderIcon(personIcon),
      },
      {
        label: () => h(
          RouterLink,
          { to: { name: "setting" } },
          { default: () => "設定" }
        ),
        key: "setting",
        icon: renderIcon(BuildIcon),
      },
      {
        label: () => h(
          'div',
          {
            onClick: logout,
          },
          { default: () => "登出" }
        ),
        key: "logout",
        icon: renderIcon(LogOutIcon),
      }
    ]
  }
]);
const logout = async () => {
  console.log('Starting logout process...');

  try {
    // 等待 Axios POST 请求完成
    const response = await axios.post('http://127.0.0.1/logout', {}, { withCredentials: true });
    console.log("Logout successful:", response.data);

    // API 调用完成且成功后的逻辑
    const logstatus = false;
    emit('logout', logstatus);
    console.log('Logout process completed');
    route.push({ name: "Login" })
  } catch (error) {
    // 处理请求出错的情况
    console.error("Logout failed:", error);
    // message.error('Something went wrong during logout');
  }
};

</script>
 
